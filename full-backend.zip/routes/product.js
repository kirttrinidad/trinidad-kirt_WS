
const r=require('express').Router();
const c=require('../controllers/product');
r.post('/', c.create);
r.get('/', c.getAll);
module.exports=r;
