
const { Product } = require('../models');

exports.create = async (req,res)=>{ res.json(await Product.create(req.body)); };
exports.getAll = async (req,res)=>{ res.json(await Product.findAll()); };
