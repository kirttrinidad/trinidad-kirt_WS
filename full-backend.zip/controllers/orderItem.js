
const { OrderItem } = require('../models');

exports.create = async (req,res)=>{ res.json(await OrderItem.create(req.body)); };
exports.getAll = async (req,res)=>{ res.json(await OrderItem.findAll()); };
