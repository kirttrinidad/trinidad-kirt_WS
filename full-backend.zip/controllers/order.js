
const { Order } = require('../models');

exports.create = async (req,res)=>{ res.json(await Order.create(req.body)); };
exports.getAll = async (req,res)=>{ res.json(await Order.findAll()); };
