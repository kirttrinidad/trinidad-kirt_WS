
const { Admin } = require('../models');

exports.create = async (req,res)=>{ res.json(await Admin.create(req.body)); };
exports.getAll = async (req,res)=>{ res.json(await Admin.findAll()); };
