
const { Payment } = require('../models');

exports.create = async (req,res)=>{ res.json(await Payment.create(req.body)); };
exports.getAll = async (req,res)=>{ res.json(await Payment.findAll()); };
