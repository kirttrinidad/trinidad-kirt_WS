
const { User } = require('../models');

exports.create = async (req,res)=>{ res.json(await User.create(req.body)); };
exports.getAll = async (req,res)=>{ res.json(await User.findAll()); };
