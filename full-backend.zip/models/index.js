
const { Sequelize, DataTypes } = require('sequelize');
const sequelize = new Sequelize({ dialect: 'sqlite', storage: 'database.db' });

const Admin = sequelize.define('Admin',{
  id:{ type:DataTypes.INTEGER, primaryKey:true, autoIncrement:true },
  name:DataTypes.STRING,
  email:DataTypes.STRING,
  password:DataTypes.STRING
});

const User = sequelize.define('User',{
  id:{ type:DataTypes.INTEGER, primaryKey:true, autoIncrement:true },
  name:DataTypes.STRING,
  email:DataTypes.STRING,
  password:DataTypes.STRING
});

const Product = sequelize.define('Product',{
  id:{ type:DataTypes.INTEGER, primaryKey:true, autoIncrement:true },
  name:DataTypes.STRING,
  price:DataTypes.FLOAT,
  stock:DataTypes.INTEGER
});

const Order = sequelize.define('Order',{
  id:{ type:DataTypes.INTEGER, primaryKey:true, autoIncrement:true },
  userID:DataTypes.INTEGER,
  total:DataTypes.FLOAT
});

const OrderItem = sequelize.define('OrderItem',{
  id:{ type:DataTypes.INTEGER, primaryKey:true, autoIncrement:true },
  orderID:DataTypes.INTEGER,
  productID:DataTypes.INTEGER,
  quantity:DataTypes.INTEGER
});

const Payment = sequelize.define('Payment',{
  id:{ type:DataTypes.INTEGER, primaryKey:true, autoIncrement:true },
  orderID:DataTypes.INTEGER,
  amount:DataTypes.FLOAT
});

module.exports = { sequelize, Admin, User, Product, Order, OrderItem, Payment };
