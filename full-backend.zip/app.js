
const express = require('express');
const bodyParser = require('body-parser');
const { sequelize } = require('./models');

const app = express();
app.use(bodyParser.json());

// Routes
app.use('/admins', require('./routes/admin'));
app.use('/users', require('./routes/user'));
app.use('/products', require('./routes/product'));
app.use('/orders', require('./routes/order'));
app.use('/orderitems', require('./routes/orderItem'));
app.use('/payments', require('./routes/payment'));

app.listen(3000, async () => {
  await sequelize.sync();
  console.log("Server running on port 3000");
});
